export interface Project {
  id: string;
  title: string;
  client: string;
  category: string;
  year: string;
  description: string;
  mainImage: string;
  deliverables: {
    title: string;
    description: string;
    images: string[];
  }[];
  overview: string;
  challenge: string;
  solution: string;
  results: string[];
}

export const projects: Project[] = [
  {
    id: "1",
    title: "EcoBlend Packaging",
    client: "EcoBlend Smoothies",
    category: "Product Design",
    year: "2024",
    description: "Sustainable packaging design for premium smoothie brand focusing on environmental consciousness.",
    mainImage: "https://images.unsplash.com/photo-1668686056289-c520e101f6b1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9kdWN0JTIwZGVzaWduJTIwcGFja2FnaW5nfGVufDF8fHx8MTc1NzM4NzMwM3ww&ixlib=rb-4.1.0&q=80&w=1080",
    overview: "A comprehensive packaging redesign for EcoBlend Smoothies, emphasizing sustainability and premium quality through innovative design solutions.",
    challenge: "The client needed packaging that would stand out on crowded shelves while clearly communicating their commitment to environmental sustainability.",
    solution: "Developed a minimalist design system using biodegradable materials with bold typography and nature-inspired color palette.",
    results: ["30% increase in brand recognition", "25% boost in sales", "Award for sustainable packaging design"],
    deliverables: [
      {
        title: "Primary Packaging",
        description: "Bottle design with eco-friendly materials and labels",
        images: ["https://images.unsplash.com/photo-1668686056289-c520e101f6b1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9kdWN0JTIwZGVzaWduJTIwcGFja2FnaW5nfGVufDF8fHx8MTc1NzM4NzMwM3ww&ixlib=rb-4.1.0&q=80&w=1080"]
      },
      {
        title: "Brand Guidelines",
        description: "Complete style guide for packaging implementation",
        images: ["https://images.unsplash.com/photo-1645658043538-fc2bb1702cfe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicmFuZCUyMGd1aWRlbGluZXMlMjBkZXNpZ24lMjBtb2NrdXB8ZW58MXx8fHwxNzU4NzA5MTQzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      },
      {
        title: "Marketing Materials",
        description: "Promotional collateral and advertising assets",
        images: ["https://images.unsplash.com/photo-1702609342206-c37562b99740?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXJrZXRpbmclMjBtYXRlcmlhbHMlMjBkZXNpZ258ZW58MXx8fHwxNzU4NzA5MTQ2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      },
      {
        title: "Product Photography",
        description: "Professional lifestyle and product photography",
        images: ["https://images.unsplash.com/photo-1641471159312-6e09825bc10b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9kdWN0JTIwcGhvdG9ncmFwaHklMjBwcm9mZXNzaW9uYWx8ZW58MXx8fHwxNzU4NzA5MTUyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      }
    ]
  },
  {
    id: "2",
    title: "Luna Cosmetics",
    client: "Luna Beauty",
    category: "Branding & Packaging",
    year: "2024",
    description: "Luxury cosmetics line featuring minimalist design with premium materials and elegant typography.",
    mainImage: "https://images.unsplash.com/photo-1699982521496-9124803b589b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3NtZXRpYyUyMGJyYW5kaW5nJTIwZGVzaWdufGVufDF8fHx8MTc1NzM4NzMwNnww&ixlib=rb-4.1.0&q=80&w=1080",
    overview: "Complete brand identity and packaging system for a new luxury cosmetics line targeting sophisticated consumers.",
    challenge: "Creating a distinctive brand in the crowded luxury cosmetics market while maintaining cost-effective production.",
    solution: "Developed an elegant monochromatic design system with premium textures and sustainable materials.",
    results: ["Featured in Vogue Beauty", "40% higher price point acceptance", "Expanded to 50+ retail locations"],
    deliverables: [
      {
        title: "Product Packaging",
        description: "Complete packaging system for 15+ products",
        images: ["https://images.unsplash.com/photo-1699982521496-9124803b589b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3NtZXRpYyUyMGJyYW5kaW5nJTIwZGVzaWdufGVufDF8fHx8MTc1NzM4NzMwNnww&ixlib=rb-4.1.0&q=80&w=1080"]
      },
      {
        title: "Brand Identity",
        description: "Logo, typography, and visual identity system",
        images: ["https://images.unsplash.com/photo-1645658043538-fc2bb1702cfe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicmFuZCUyMGd1aWRlbGluZXMlMjBkZXNpZ24lMjBtb2NrdXB8ZW58MXx8fHwxNzU4NzA5MTQzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      },
      {
        title: "Digital Mockups",
        description: "Website and social media presentation assets",
        images: ["https://images.unsplash.com/photo-1649151139875-ae8ea07082e2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWdpdGFsJTIwbW9ja3VwJTIwcHJlc2VudGF0aW9ufGVufDF8fHx8MTc1ODcwOTE0OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      },
      {
        title: "Retail Displays",
        description: "Point-of-sale materials and display systems",
        images: ["https://images.unsplash.com/photo-1702609342206-c37562b99740?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXJrZXRpbmclMjBtYXRlcmlhbHMlMjBkZXNpZ258ZW58MXx8fHwxNzU4NzA5MTQ2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      }
    ]
  },
  {
    id: "3",
    title: "Farm Fresh Foods",
    client: "Farm Fresh Co.",
    category: "Food Packaging",
    year: "2023",
    description: "Organic food packaging design emphasizing freshness and natural ingredients.",
    mainImage: "https://images.unsplash.com/photo-1653174577821-9ab410d92d44?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb29kJTIwcGFja2FnaW5nJTIwZGVzaWdufGVufDF8fHx8MTc1NzM4NzMwOXww&ixlib=rb-4.1.0&q=80&w=1080",
    overview: "Redesign of product packaging for organic food company to better communicate quality and freshness.",
    challenge: "Standing out in the organic food market while maintaining cost-effective packaging solutions.",
    solution: "Clean, nature-inspired design with clear product visibility and sustainable materials.",
    results: ["20% increase in sales", "Improved shelf presence", "Reduced packaging costs by 15%"],
    deliverables: [
      {
        title: "Package Design System",
        description: "Flexible system for 25+ food products",
        images: ["https://images.unsplash.com/photo-1653174577821-9ab410d92d44?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb29kJTIwcGFja2FnaW5nJTIwZGVzaWdufGVufDF8fHx8MTc1NzM4NzMwOXww&ixlib=rb-4.1.0&q=80&w=1080"]
      },
      {
        title: "Label Designs",
        description: "Nutritional and ingredient label templates",
        images: ["https://images.unsplash.com/photo-1645658043538-fc2bb1702cfe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicmFuZCUyMGd1aWRlbGluZXMlMjBkZXNpZ24lMjBtb2NrdXB8ZW58MXx8fHwxNzU4NzA5MTQzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      },
      {
        title: "Product Photography",
        description: "Fresh food styling and lifestyle photography",
        images: ["https://images.unsplash.com/photo-1641471159312-6e09825bc10b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9kdWN0JTIwcGhvdG9ncmFwaHklMjBwcm9mZXNzaW9uYWx8ZW58MXx8fHwxNzU4NzA5MTUyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      },
      {
        title: "Retail Materials",
        description: "Shelf talkers and promotional displays",
        images: ["https://images.unsplash.com/photo-1702609342206-c37562b99740?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXJrZXRpbmclMjBtYXRlcmlhbHMlMjBkZXNpZ258ZW58MXx8fHwxNzU4NzA5MTQ2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      }
    ]
  },
  {
    id: "4",
    title: "TechFlow Devices",
    client: "TechFlow Inc.",
    category: "Product Design",
    year: "2023",
    description: "Modern tech product packaging with focus on innovation and premium user experience.",
    mainImage: "https://images.unsplash.com/photo-1560461396-ec0ef7bb29dd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNoJTIwcHJvZHVjdCUyMGRlc2lnbnxlbnwxfHx8fDE3NTczODczMTF8MA&ixlib=rb-4.1.0&q=80&w=1080",
    overview: "Packaging design for cutting-edge tech products that reflects innovation and premium quality.",
    challenge: "Creating packaging that protects sensitive electronics while delivering an premium unboxing experience.",
    solution: "Sleek, modern design with innovative protective features and sustainable materials.",
    results: ["95% customer satisfaction", "Reduced shipping damage by 40%", "Featured in tech publications"],
    deliverables: [
      {
        title: "Product Packaging",
        description: "Protective and premium packaging solution",
        images: ["https://images.unsplash.com/photo-1560461396-ec0ef7bb29dd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNoJTIwcHJvZHVjdCUyMGRlc2lnbnxlbnwxfHx8fDE3NTczODczMTF8MA&ixlib=rb-4.1.0&q=80&w=1080"]
      },
      {
        title: "User Manual Design",
        description: "Technical documentation and setup guides",
        images: ["https://images.unsplash.com/photo-1645658043538-fc2bb1702cfe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicmFuZCUyMGd1aWRlbGluZXMlMjBkZXNpZ24lMjBtb2NrdXB8ZW58MXx8fHwxNzU4NzA5MTQzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      },
      {
        title: "Digital Experience",
        description: "App interface and digital touchpoints",
        images: ["https://images.unsplash.com/photo-1649151139875-ae8ea07082e2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWdpdGFsJTIwbW9ja3VwJTIwcHJlc2VudGF0aW9ufGVufDF8fHx8MTc1ODcwOTE0OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      },
      {
        title: "Marketing Campaign",
        description: "Launch materials and advertising assets",
        images: ["https://images.unsplash.com/photo-1702609342206-c37562b99740?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXJrZXRpbmclMjBtYXRlcmlhbHMlMjBkZXNpZ258ZW58MXx8fHwxNzU4NzA5MTQ2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      }
    ]
  },
  {
    id: "5",
    title: "Prestige Collection",
    client: "Luxury Brands Ltd.",
    category: "Luxury Packaging",
    year: "2023",
    description: "Ultra-premium packaging design for high-end luxury goods with exceptional attention to detail.",
    mainImage: "https://images.unsplash.com/photo-1566977806197-b52b166f231f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBicmFuZCUyMHBhY2thZ2luZ3xlbnwxfHx8fDE3NTczODczMTR8MA&ixlib=rb-4.1.0&q=80&w=1080",
    overview: "Exclusive packaging design for ultra-luxury products targeting high-net-worth individuals.",
    challenge: "Creating packaging that justifies premium pricing and creates memorable luxury experiences.",
    solution: "Handcrafted design elements with premium materials and exceptional attention to detail.",
    results: ["50% increase in gift purchases", "100% client retention", "Industry design award"],
    deliverables: [
      {
        title: "Luxury Packaging Suite",
        description: "Complete luxury packaging system",
        images: ["https://images.unsplash.com/photo-1566977806197-b52b166f231f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBicmFuZCUyMHBhY2thZ2luZ3xlbnwxfHx8fDE3NTczODczMTR8MA&ixlib=rb-4.1.0&q=80&w=1080"]
      },
      {
        title: "Premium Collateral",
        description: "High-end brochures and presentation materials",
        images: ["https://images.unsplash.com/photo-1645658043538-fc2bb1702cfe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicmFuZCUyMGd1aWRlbGluZXMlMjBkZXNpZ24lMjBtb2NrdXB8ZW58MXx8fHwxNzU4NzA5MTQzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      },
      {
        title: "Lifestyle Photography",
        description: "Luxury product and lifestyle photography",
        images: ["https://images.unsplash.com/photo-1641471159312-6e09825bc10b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9kdWN0JTIwcGhvdG9ncmFwaHklMjBwcm9mZXNzaW9uYWx8ZW58MXx8fHwxNzU4NzA5MTUyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      },
      {
        title: "Digital Presence",
        description: "Website and social media assets",
        images: ["https://images.unsplash.com/photo-1649151139875-ae8ea07082e2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWdpdGFsJTIwbW9ja3VwJTIwcHJlc2VudGF0aW9ufGVufDF8fHx8MTc1ODcwOTE0OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      }
    ]
  },
  {
    id: "6",
    title: "Pure Energy Drinks",
    client: "Pure Energy Co.",
    category: "Beverage Branding",
    year: "2022",
    description: "Energetic and bold beverage packaging design targeting active lifestyle consumers.",
    mainImage: "https://images.unsplash.com/photo-1641771569525-9db53fd31fd5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZXZlcmFnZSUyMGJyYW5kaW5nJTIwZGVzaWdufGVufDF8fHx8MTc1NzM4NzMxN3ww&ixlib=rb-4.1.0&q=80&w=1080",
    overview: "Dynamic packaging design for energy drink brand targeting fitness enthusiasts and active professionals.",
    challenge: "Breaking into the competitive energy drink market with a health-conscious positioning.",
    solution: "Bold, athletic-inspired design with clear nutritional messaging and premium materials.",
    results: ["Launched in 500+ stores", "25% market share in target segment", "Sponsored 3 major sports events"],
    deliverables: [
      {
        title: "Can Design System",
        description: "Complete beverage packaging solution",
        images: ["https://images.unsplash.com/photo-1641771569525-9db53fd31fd5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZXZlcmFnZSUyMGJyYW5kaW5nJTIwZGVzaWdufGVufDF8fHx8MTc1NzM4NzMxN3ww&ixlib=rb-4.1.0&q=80&w=1080"]
      },
      {
        title: "Brand Identity",
        description: "Logo design and athletic brand system",
        images: ["https://images.unsplash.com/photo-1645658043538-fc2bb1702cfe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicmFuZCUyMGd1aWRlbGluZXMlMjBkZXNpZ24lMjBtb2NrdXB8ZW58MXx8fHwxNzU4NzA5MTQzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      },
      {
        title: "Sports Marketing",
        description: "Athletic sponsorship and event materials",
        images: ["https://images.unsplash.com/photo-1702609342206-c37562b99740?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXJrZXRpbmclMjBtYXRlcmlhbHMlMjBkZXNpZ258ZW58MXx8fHwxNzU4NzA5MTQ2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      },
      {
        title: "Digital Campaign",
        description: "Social media and digital advertising",
        images: ["https://images.unsplash.com/photo-1649151139875-ae8ea07082e2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWdpdGFsJTIwbW9ja3VwJTIwcHJlc2VudGF0aW9ufGVufDF8fHx8MTc1ODcwOTE0OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      }
    ]
  },
  {
    id: "7",
    title: "Urban Style Collection",
    client: "Urban Fashion House",
    category: "Fashion Branding",
    year: "2022",
    description: "Contemporary fashion brand identity and packaging for urban streetwear collection.",
    mainImage: "https://images.unsplash.com/photo-1662393792373-52f5477094f6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXNoaW9uJTIwYnJhbmQlMjBkZXNpZ258ZW58MXx8fHwxNTczODczMTl8MA&ixlib=rb-4.1.0&q=80&w=1080",
    overview: "Street-inspired brand identity for fashion startup targeting urban millennials and Gen Z consumers.",
    challenge: "Creating authentic street culture brand that resonates with young urban consumers.",
    solution: "Edgy, contemporary design with street art influences and sustainable packaging.",
    results: ["Instagram following: 100K+", "Collaboration with 5 influencers", "Pop-up store success"],
    deliverables: [
      {
        title: "Brand Identity Package",
        description: "Complete fashion brand identity system",
        images: ["https://images.unsplash.com/photo-1662393792373-52f5477094f6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXNoaW9uJTIwYnJhbmQlMjBkZXNpZ258ZW58MXx8fHwxNTczODczMTl8MA&ixlib=rb-4.1.0&q=80&w=1080"]
      },
      {
        title: "Apparel Graphics",
        description: "T-shirt designs and garment graphics",
        images: ["https://images.unsplash.com/photo-1645658043538-fc2bb1702cfe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicmFuZCUyMGd1aWRlbGluZXMlMjBkZXNpZ24lMjBtb2NrdXB8ZW58MXx8fHwxNzU4NzA5MTQzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      },
      {
        title: "Street Photography",
        description: "Urban lifestyle and product photography",
        images: ["https://images.unsplash.com/photo-1641471159312-6e09825bc10b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9kdWN0JTIwcGhvdG9ncmFwaHklMjBwcm9mZXNzaW9uYWx8ZW58MXx8fHwxNzU4NzA5MTUyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      },
      {
        title: "Social Media Assets",
        description: "Instagram and digital content creation",
        images: ["https://images.unsplash.com/photo-1649151139875-ae8ea07082e2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWdpdGFsJTIwbW9ja3VwJTIwcHJlc2VudGF0aW9ufGVufDF8fHx8MTc1ODcwOTE0OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      }
    ]
  },
  {
    id: "8",
    title: "GreenPack Solutions",
    client: "EcoPackaging Corp.",
    category: "Sustainable Design",
    year: "2022",
    description: "Innovative sustainable packaging solutions for environmentally conscious brands.",
    mainImage: "https://images.unsplash.com/photo-1755605573547-b12e19a021db?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdXN0YWluYWJsZSUyMHBhY2thZ2luZyUyMGRlc2lnbnxlbnwxfHx8fDE3NTczODcwNjl8MA&ixlib=rb-4.1.0&q=80&w=1080",
    overview: "Revolutionary packaging design using 100% recyclable materials for forward-thinking brands.",
    challenge: "Balancing environmental responsibility with practical packaging requirements and cost constraints.",
    solution: "Innovative material combinations with zero-waste design principles and modular construction.",
    results: ["60% reduction in packaging waste", "Carbon neutral certification", "Industry sustainability award"],
    deliverables: [
      {
        title: "Sustainable Package System",
        description: "Eco-friendly packaging solutions",
        images: ["https://images.unsplash.com/photo-1755605573547-b12e19a021db?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdXN0YWluYWJsZSUyMHBhY2thZ2luZyUyMGRlc2lnbnxlbnwxfHx8fDE3NTczODcwNjl8MA&ixlib=rb-4.1.0&q=80&w=1080"]
      },
      {
        title: "Eco-Guidelines",
        description: "Sustainability standards and certifications",
        images: ["https://images.unsplash.com/photo-1645658043538-fc2bb1702cfe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicmFuZCUyMGd1aWRlbGluZXMlMjBkZXNpZ24lMjBtb2NrdXB8ZW58MXx8fHwxNzU4NzA5MTQzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      },
      {
        title: "Educational Materials",
        description: "Consumer education and awareness campaigns",
        images: ["https://images.unsplash.com/photo-1702609342206-c37562b99740?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXJrZXRpbmclMjBtYXRlcmlhbHMlMjBkZXNpZ258ZW58MXx8fHwxNzU4NzA5MTQ2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      },
      {
        title: "Case Studies",
        description: "Impact documentation and success stories",
        images: ["https://images.unsplash.com/photo-1649151139875-ae8ea07082e2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWdpdGFsJTIwbW9ja3VwJTIwcHJlc2VudGF0aW9ufGVufDF8fHx8MTc1ODcwOTE0OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      }
    ]
  },
  {
    id: "9",
    title: "VitalHealth Products",
    client: "VitalHealth Inc.",
    category: "Healthcare Branding",
    year: "2021",
    description: "Clean and trustworthy packaging design for health and wellness product line.",
    mainImage: "https://images.unsplash.com/photo-1661395281287-be507cb4e409?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFsdGglMjBwcm9kdWN0JTIwYnJhbmRpbmd8ZW58MXx8fHwxNzU3Mzg3MzI1fDA&ixlib=rb-4.1.0&q=80&w=1080",
    overview: "Medical-grade packaging design for health supplements emphasizing trust and scientific credibility.",
    challenge: "Creating consumer appeal while maintaining medical credibility and regulatory compliance.",
    solution: "Clean, clinical design with clear information hierarchy and premium materials.",
    results: ["FDA approval success", "Pharmacy partnerships", "Healthcare professional endorsements"],
    deliverables: [
      {
        title: "Medical Packaging Series",
        description: "Compliant healthcare product packaging",
        images: ["https://images.unsplash.com/photo-1661395281287-be507cb4e409?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFsdGglMjBwcm9kdWN0JTIwYnJhbmRpbmd8ZW58MXx8fHwxNzU3Mzg3MzI1fDA&ixlib=rb-4.1.0&q=80&w=1080"]
      },
      {
        title: "Information Design",
        description: "Clear dosage and usage instructions",
        images: ["https://images.unsplash.com/photo-1645658043538-fc2bb1702cfe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicmFuZCUyMGd1aWRlbGluZXMlMjBkZXNpZ24lMjBtb2NrdXB8ZW58MXx8fHwxNzU4NzA5MTQzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      },
      {
        title: "Professional Materials",
        description: "Healthcare provider documentation",
        images: ["https://images.unsplash.com/photo-1702609342206-c37562b99740?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXJrZXRpbmclMjBtYXRlcmlhbHMlMjBkZXNpZ258ZW58MXx8fHwxNzU4NzA5MTQ2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      },
      {
        title: "Clinical Photography",
        description: "Product and lifestyle medical photography",
        images: ["https://images.unsplash.com/photo-1641471159312-6e09825bc10b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9kdWN0JTIwcGhvdG9ncmFwaHklMjBwcm9mZXNzaW9uYWx8ZW58MXx8fHwxNzU4NzA5MTUyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      }
    ]
  },
  {
    id: "10",
    title: "NextGen Startups",
    client: "Innovation Labs",
    category: "Brand Identity",
    year: "2021",
    description: "Modern brand identity system for tech startup incubator and their portfolio companies.",
    mainImage: "https://images.unsplash.com/photo-1590102426275-8d1c367070d3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHhzdGFydHVwJTIwYnJhbmQlMjBpZGVudGl0eXxlbnwxfHx8fDE3NTczODczMjd8MA&ixlib=rb-4.1.0&q=80&w=1080",
    overview: "Comprehensive brand system for startup incubator and flexible sub-brand architecture.",
    challenge: "Creating cohesive identity system that works for diverse portfolio of startup companies.",
    solution: "Modular brand architecture with flexible visual elements and scalable design system.",
    results: ["30+ startups branded", "Increased investor interest", "Successful IPO for 3 companies"],
    deliverables: [
      {
        title: "Brand Architecture System",
        description: "Scalable identity system for multiple brands",
        images: ["https://images.unsplash.com/photo-1590102426275-8d1c367070d3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHhzdGFydHVwJTIwYnJhbmQlMjBpZGVudGl0eXxlbnwxfHx8fDE3NTczODczMjd8MA&ixlib=rb-4.1.0&q=80&w=1080"]
      },
      {
        title: "Portfolio Templates",
        description: "Presentation materials for startups",
        images: ["https://images.unsplash.com/photo-1645658043538-fc2bb1702cfe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicmFuZCUyMGd1aWRlbGluZXMlMjBkZXNpZ24lMjBtb2NrdXB8ZW58MXx8fHwxNzU4NzA5MTQzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      },
      {
        title: "Digital Ecosystem",
        description: "Website and app design systems",
        images: ["https://images.unsplash.com/photo-1649151139875-ae8ea07082e2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWdpdGFsJTIwbW9ja3VwJTIwcHJlc2VudGF0aW9ufGVufDF8fHx8MTc1ODcwOTE0OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      },
      {
        title: "Investment Materials",
        description: "Pitch decks and investor relations design",
        images: ["https://images.unsplash.com/photo-1702609342206-c37562b99740?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXJrZXRpbmclMjBtYXRlcmlhbHMlMjBkZXNpZ258ZW58MXx8fHwxNzU4NzA5MTQ2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"]
      }
    ]
  }
];