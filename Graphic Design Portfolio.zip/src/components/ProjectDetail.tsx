import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { projects } from '../data/projects';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function ProjectDetail() {
  const { id } = useParams<{ id: string }>();
  const project = projects.find(p => p.id === id);

  if (!project) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-32 text-center">
        <h1 className="serif text-4xl text-primary mb-8">Project Not Found</h1>
        <Link 
          to="/gallery" 
          className="inline-flex items-center text-primary hover:text-primary/70 transition-colors sans text-sm tracking-wider uppercase"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Portfolio
        </Link>
      </div>
    );
  }

  return (
    <main className="min-h-screen pt-32 pb-16 bg-background">
      {/* Navigation */}
      <div className="px-16 mb-12">
        <Link 
          to="/gallery" 
          className="inline-flex items-center text-muted-foreground hover:text-primary transition-colors sans text-sm tracking-wider uppercase"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Portfolio
        </Link>
      </div>

      {/* Hero Section */}
      <div className="px-16 mb-24">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-12 gap-16 items-end">
            <div className="col-span-8">
              <h1 className="serif text-6xl text-primary mb-6">{project.title}</h1>
              <p className="editorial-text max-w-2xl">
                {project.description}
              </p>
            </div>
            <div className="col-span-4 text-right">
              <div className="space-y-4">
                <div>
                  <h4 className="sans text-xs uppercase tracking-wide text-muted-foreground mb-1">Category</h4>
                  <p className="serif text-lg text-primary">{project.category}</p>
                </div>
                <div>
                  <h4 className="sans text-xs uppercase tracking-wide text-muted-foreground mb-1">Year</h4>
                  <p className="serif text-lg text-primary">2024</p>
                </div>
                <div>
                  <h4 className="sans text-xs uppercase tracking-wide text-muted-foreground mb-1">Services</h4>
                  <p className="sans text-sm text-muted-foreground">
                    Brand Identity, Packaging Design, Art Direction
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Project Image */}
      <div className="px-16 mb-24">
        <div className="max-w-7xl mx-auto">
          <div className="aspect-[16/9] w-full">
            <ImageWithFallback 
              src={project.mainImage}
              alt={project.title}
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>

      {/* Project Details */}
      <div className="px-16 mb-24">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-2 gap-24">
            <div>
              <h2 className="serif text-3xl text-primary mb-8">
                The <span className="script-text">Challenge</span>
              </h2>
              <div className="space-y-6 editorial-text">
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod 
                  tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim 
                  veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.
                </p>
                <p>
                  Duis aute irure dolor in reprehenderit in voluptate velit esse cillum 
                  dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non 
                  proident, sunt in culpa qui officia deserunt.
                </p>
              </div>
            </div>
            <div>
              <h2 className="serif text-3xl text-primary mb-8">
                The <span className="script-text">Solution</span>
              </h2>
              <div className="space-y-6 editorial-text">
                <p>
                  Mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus 
                  error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, 
                  eaque ipsa quae ab illo inventore veritatis.
                </p>
                <p>
                  Et harum quidem rerum facilis est et expedita distinctio. Nam libero 
                  tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo 
                  minus id quod maxime placeat facere possimus.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Deliverables Grid */}
      <div className="px-16 mb-24">
        <div className="max-w-7xl mx-auto">
          <h2 className="serif text-4xl text-primary text-center mb-16">
            Project <span className="script-text">Deliverables</span>
          </h2>
          
          <div className="grid grid-cols-2 gap-8 mb-16">
            {project.deliverables.slice(0, 4).map((deliverable, index) => (
              <div key={index} className="space-y-4">
                <div className="aspect-[4/3]">
                  <ImageWithFallback 
                    src={deliverable.images[0] || project.mainImage}
                    alt={deliverable.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="text-center">
                  <h3 className="serif text-xl text-primary mb-2">{deliverable.name}</h3>
                  <p className="sans text-sm text-muted-foreground">{deliverable.description}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Additional Images Grid */}
          {project.deliverables.length > 4 && (
            <div className="grid grid-cols-3 gap-6">
              {project.deliverables.slice(4).map((deliverable, index) => (
                <div key={index} className="aspect-square">
                  <ImageWithFallback 
                    src={deliverable.images[0] || project.mainImage}
                    alt={deliverable.name}
                    className="w-full h-full object-cover"
                  />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Next Project */}
      <div className="px-16 py-24 bg-secondary/20">
        <div className="max-w-6xl mx-auto text-center">
          <h3 className="serif text-3xl text-primary mb-6">
            Explore More <span className="script-text">Work</span>
          </h3>
          <p className="editorial-text mb-12 max-w-xl mx-auto">
            Discover other projects that showcase our commitment to exceptional design 
            and meaningful brand experiences.
          </p>
          <Link 
            to="/gallery"
            className="inline-block px-12 py-4 border border-primary text-primary hover:bg-primary hover:text-primary-foreground transition-colors sans text-sm tracking-wider uppercase"
          >
            View All Projects
          </Link>
        </div>
      </div>
    </main>
  );
}