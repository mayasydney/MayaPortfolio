import React from 'react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function About() {
  return (
    <main className="min-h-screen pt-32 pb-16 bg-background">
      {/* Hero Section */}
      <div className="px-16 mb-24">
        <div className="max-w-6xl mx-auto text-center">
          <h1 className="serif text-6xl text-primary mb-8">
            Meet the <span className="script-text">Designer</span>
          </h1>
          <div className="w-32 h-px bg-primary mx-auto mb-8"></div>
          <p className="editorial-text max-w-2xl mx-auto">
            Passionate about creating meaningful connections between brands and their audiences 
            through thoughtful design and compelling visual storytelling.
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="px-16">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-12 gap-16 items-center mb-24">
            {/* Left - Portrait */}
            <div className="col-span-5">
              <div className="aspect-[4/5]">
                <ImageWithFallback 
                  src="https://images.unsplash.com/photo-1753162660733-45bcad593b16?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcmVhdGl2ZSUyMGRlc2lnbmVyJTIwcG9ydHJhaXR8ZW58MXx8fHwxNzU3NDgyMDQ1fDA&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="MC - Creative Director"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            {/* Right - Bio */}
            <div className="col-span-7 pl-8">
              <h2 className="serif text-4xl text-primary mb-8">
                Creative Director & <br />
                <span className="script-text">Brand Specialist</span>
              </h2>
              
              <div className="space-y-6 editorial-text">
                <p>
                  With over a decade of experience in the design industry, I've had the privilege 
                  of working with brands across luxury goods, cosmetics, food & beverage, and 
                  sustainable design sectors. My approach centers on understanding the essence 
                  of each brand and translating that into visual experiences that resonate.
                </p>
                
                <p>
                  Every project begins with deep listening—understanding not just what a brand 
                  does, but why it exists and who it serves. This foundation allows me to create 
                  designs that aren't just beautiful, but meaningful and effective.
                </p>
                
                <p>
                  Based in New York, I collaborate with clients globally, bringing together 
                  strategic thinking and creative execution to build brands that stand the test 
                  of time.
                </p>
              </div>

              <div className="mt-12">
                <h3 className="serif text-xl text-primary mb-4">Philosophy</h3>
                <blockquote className="script-text text-lg text-primary border-l-2 border-primary pl-6">
                  "Design is not just about making things look beautiful—it's about creating 
                  connections that matter."
                </blockquote>
              </div>
            </div>
          </div>

          {/* Services & Approach */}
          <div className="grid grid-cols-3 gap-16 mb-24">
            <div>
              <h3 className="serif text-2xl text-primary mb-6">Services</h3>
              <ul className="space-y-3 text-muted-foreground">
                <li className="sans text-sm tracking-wide">• Brand Identity Design</li>
                <li className="sans text-sm tracking-wide">• Packaging & Product Design</li>
                <li className="sans text-sm tracking-wide">• Print & Digital Collateral</li>
                <li className="sans text-sm tracking-wide">• Art Direction</li>
                <li className="sans text-sm tracking-wide">• Design Strategy</li>
                <li className="sans text-sm tracking-wide">• Creative Consultation</li>
              </ul>
            </div>

            <div>
              <h3 className="serif text-2xl text-primary mb-6">Industries</h3>
              <ul className="space-y-3 text-muted-foreground">
                <li className="sans text-sm tracking-wide">• Beauty & Cosmetics</li>
                <li className="sans text-sm tracking-wide">• Food & Beverage</li>
                <li className="sans text-sm tracking-wide">• Luxury Goods</li>
                <li className="sans text-sm tracking-wide">• Fashion & Lifestyle</li>
                <li className="sans text-sm tracking-wide">• Sustainable Design</li>
                <li className="sans text-sm tracking-wide">• Technology</li>
              </ul>
            </div>

            <div>
              <h3 className="serif text-2xl text-primary mb-6">Recognition</h3>
              <ul className="space-y-3 text-muted-foreground">
                <li className="sans text-sm tracking-wide">• Dieline Package Design Awards</li>
                <li className="sans text-sm tracking-wide">• Communication Arts Design Annual</li>
                <li className="sans text-sm tracking-wide">• Graphis Design Annual</li>
                <li className="sans text-sm tracking-wide">• AIGA 50 Best</li>
                <li className="sans text-sm tracking-wide">• HOW International Design Awards</li>
              </ul>
            </div>
          </div>

          {/* Contact CTA */}
          <div className="text-center py-16 border-t border-border">
            <h3 className="serif text-3xl text-primary mb-6">
              Ready to Create Something <span className="script-text">Extraordinary?</span>
            </h3>
            <p className="editorial-text mb-8 max-w-xl mx-auto">
              I'm currently accepting new projects and would love to hear about your vision. 
              Let's start a conversation about how we can bring your brand to life.
            </p>
            <div className="flex flex-col sm:flex-row justify-center items-center gap-6">
              <a 
                href="mailto:hello@mc-studio.com"
                className="px-12 py-4 border border-primary text-primary hover:bg-primary hover:text-primary-foreground transition-colors sans text-sm tracking-wider uppercase"
              >
                Email Me
              </a>
              <div className="text-center">
                <p className="sans text-xs text-muted-foreground uppercase tracking-wide mb-1">Or Call</p>
                <a href="tel:+1234567890" className="serif text-lg text-primary">
                  +1 (234) 567-8900
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}