import React from 'react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Link } from 'react-router-dom';

export function Homepage() {
  return (
    <main className="min-h-screen bg-background">
      {/* Hero Section with Featured Works */}
      <section className="relative h-screen flex flex-col overflow-hidden">
        {/* Main Brand Section */}
        <div className="flex-1 flex items-center justify-center relative z-20">
          <div className="text-center">
            <div className="w-48 h-48 mx-auto">
              <ImageWithFallback 
                src="https://images.unsplash.com/photo-1649000808933-1f4aac7cad9a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwbG9nbyUyMGRlc2lnbiUyMG1pbmltYWx8ZW58MXx8fHwxNzU4MDI0OTEyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="MC Logo"
                className="w-full h-full object-contain"
              />
            </div>
          </div>
        </div>
        
        {/* Featured Work 1 - Random position */}
        <div className="absolute top-8 right-24 w-80 h-96 z-10 group">
          <Link to="/gallery" className="block h-full">
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1667857891884-56493d5a92be?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwZmxvcmFsJTIwYXJyYW5nZW1lbnR8ZW58MXx8fHwxNzU3NDg3MzMyfDA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Luxury Beauty Branding"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
          </Link>
        </div>

        {/* Featured Work 2 - Random position */}
        <div className="absolute top-32 left-6 w-72 h-80 z-10 group">
          <Link to="/gallery" className="block h-full">
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1595591639066-25b7c61e17e2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjB3aW5lJTIwcGFja2FnaW5nfGVufDF8fHx8MTc1NzQ4NzY4OXww&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Premium Wine Collection"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
          </Link>
        </div>

        {/* Featured Work 3 - Random position */}
        <div className="absolute top-44 left-80 w-64 h-72 z-10 group">
          <Link to="/gallery" className="block h-full">
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1535954906091-59dea18fac73?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNoJTIwc3RhcnR1cCUyMGJyYW5kaW5nfGVufDF8fHx8MTc1NzQyNDc5OHww&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Tech Startup Identity"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
          </Link>
        </div>

        {/* Featured Work 4 - Random position */}
        <div className="absolute bottom-16 right-8 w-96 h-64 z-10 group">
          <Link to="/gallery" className="block h-full">
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1746422029443-7bb5746f6209?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcnRpc2FuJTIwY29mZmVlJTIwcGFja2FnaW5nfGVufDF8fHx8MTc1NzQ4NzY5NXww&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Artisan Coffee Packaging"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
          </Link>
        </div>

        {/* Featured Work 5 - Random position */}
        <div className="absolute bottom-8 left-16 w-76 h-88 z-10 group">
          <Link to="/gallery" className="block h-full">
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1755605573547-b12e19a021db?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdXN0YWluYWJsZSUyMHBhY2thZ2luZyUyMGRlc2lnbnxlbnwxfHx8fDE3NTczODcwNjl8MA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Sustainable Design"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
          </Link>
        </div>

        {/* Featured Work 6 - Random position */}
        <div className="absolute top-56 right-72 w-80 h-60 z-10 group">
          <Link to="/gallery" className="block h-full">
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1634047222187-0b830109edfa?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXNoaW9uJTIwYnJhbmQlMjBpZGVudGl0eXxlbnwxfHx8fDE3NTc0ODc3MDB8MA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Fashion Brand Identity"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
          </Link>
        </div>

        {/* Featured Work 7 - Random position */}
        <div className="absolute top-20 left-96 w-60 h-68 z-10 group">
          <Link to="/gallery" className="block h-full">
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1739918041927-f9001c82ac88?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjByZXN0YXVyYW50JTIwYnJhbmRpbmd8ZW58MXx8fHwxNzU3NDg4NTc0fDA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Modern Restaurant Branding"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
          </Link>
        </div>

        {/* Featured Work 8 - Random position */}
        <div className="absolute bottom-32 right-96 w-72 h-56 z-10 group">
          <Link to="/gallery" className="block h-full">
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1734779527847-36b505579c85?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwamV3ZWxyeSUyMHBhY2thZ2luZ3xlbnwxfHx8fDE3NTc0ODg1Nzd8MA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Elegant Jewelry Packaging"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
          </Link>
        </div>

        {/* Featured Work 9 - Random position */}
        <div className="absolute top-80 left-12 w-80 h-56 z-10 group">
          <Link to="/gallery" className="block h-full">
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1634406005209-6adbbf0b935f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsaXN0JTIwYm9vayUyMGRlc2lnbnxlbnwxfHx8fDE3NTc0ODg1ODB8MA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Minimalist Book Design"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
          </Link>
        </div>

        {/* Featured Work 10 - Random position */}
        <div className="absolute bottom-40 left-80 w-68 h-84 z-10 group">
          <Link to="/gallery" className="block h-full">
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1743309026555-97f545a08490?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBzcGElMjBicmFuZGluZ3xlbnwxfHx8fDE3NTc0ODg1ODN8MA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Luxury Spa Branding"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
          </Link>
        </div>

        {/* Decorative Elements */}
        <div className="absolute top-1/3 left-1/3 w-2 h-2 bg-primary rounded-full opacity-60 z-5"></div>
      </section>

      {/* Philosophy Section */}
      <section className="py-32 px-16 bg-secondary/30">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="serif text-5xl text-primary mb-8">
            Not Just Images,<br />
            <span className="script-text">But Connections</span>
          </h2>
          <div className="max-w-3xl mx-auto">
            <p className="editorial-text mb-8">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor 
              incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis 
              nostrud exercitation ullamco laboris.
            </p>
            <p className="editorial-text">
              Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore 
              eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident.
            </p>
          </div>
          <Link 
            to="/gallery"
            className="inline-block mt-12 px-8 py-3 border border-primary text-primary hover:bg-primary hover:text-primary-foreground transition-colors sans text-sm tracking-wider uppercase"
          >
            View Portfolio
          </Link>
        </div>
      </section>

      {/* Featured Projects Section */}
      <section className="py-32 px-16">
        <div className="max-w-7xl mx-auto">
          {/* Large Feature Image */}
          <div className="relative mb-24">
            <div className="aspect-[16/9] w-full">
              <ImageWithFallback 
                src="https://images.unsplash.com/photo-1677890465835-ab8c5c621771?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBicmFuZGluZyUyMGRlc2lnbnxlbnwxfHx8fDE3NTc0ODczMzV8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Luxury Branding Project"
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Two Column Layout */}
          <div className="grid grid-cols-2 gap-24">
            {/* Left Column - Text */}
            <div className="pt-16">
              <h3 className="serif text-4xl text-primary mb-8">
                <span className="script-text">Luxury</span><br />
                Branding
              </h3>
              <p className="editorial-text mb-6">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod 
                tempor incididunt ut labore et dolore magna aliqua.
              </p>
              <ul className="space-y-3 text-muted-foreground">
                <li className="sans text-sm tracking-wide">• Brand Identity Design</li>
                <li className="sans text-sm tracking-wide">• Packaging Solutions</li>
                <li className="sans text-sm tracking-wide">• Digital Applications</li>
                <li className="sans text-sm tracking-wide">• Print Collateral</li>
              </ul>
              <Link 
                to="/gallery"
                className="inline-block mt-8 text-primary hover:text-primary/70 transition-colors sans text-sm tracking-wider uppercase border-b border-primary"
              >
                Explore Projects
              </Link>
            </div>

            {/* Right Column - Images */}
            <div className="space-y-8">
              <div className="aspect-[4/3]">
                <ImageWithFallback 
                  src="https://images.unsplash.com/photo-1751991713869-7e5ae07db1fb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBwYWNrYWdpbmclMjBkZXNpZ258ZW58MXx8fHwxNzU3NDE5MDY1fDA&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="Packaging Design"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="aspect-square bg-muted border border-border flex items-center justify-center">
                  <span className="serif text-lg text-muted-foreground">Logo Design</span>
                </div>
                <div className="aspect-square bg-muted border border-border flex items-center justify-center">
                  <span className="serif text-lg text-muted-foreground">Typography</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Bottom Section - Specialties */}
      <section className="py-24 px-16 bg-secondary/20">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-3 gap-16">
            <div className="text-center">
              <h4 className="serif text-2xl text-primary mb-4">Cosmetics</h4>
              <p className="sans text-sm text-muted-foreground">
                Beauty brand identity & packaging that captures elegance and sophistication.
              </p>
            </div>
            <div className="text-center">
              <h4 className="serif text-2xl text-primary mb-4">Food & Beverage</h4>
              <p className="sans text-sm text-muted-foreground">
                Appetizing designs that tell your brand's story through visual taste.
              </p>
            </div>
            <div className="text-center">
              <h4 className="serif text-2xl text-primary mb-4">Luxury Goods</h4>
              <p className="sans text-sm text-muted-foreground">
                Premium branding that reflects quality, heritage, and exclusivity.
              </p>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}