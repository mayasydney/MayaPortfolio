import React from 'react';
import { Link } from 'react-router-dom';
import { projects } from '../data/projects';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function Gallery() {
  return (
    <main className="min-h-screen pt-32 pb-16 px-16 bg-background">
      {/* Hero Section */}
      <div className="max-w-6xl mx-auto text-center mb-24">
        <h1 className="serif text-6xl text-primary mb-8">
          <span className="script-text">Selected</span> Works
        </h1>
        <div className="w-32 h-px bg-primary mx-auto mb-8"></div>
        <p className="editorial-text max-w-2xl mx-auto">
          A curated collection of brand identities, packaging designs, and creative solutions 
          crafted for discerning clients across various industries.
        </p>
      </div>

      {/* Featured Project */}
      <div className="max-w-7xl mx-auto mb-24">
        <div className="relative">
          <div className="aspect-[16/10] w-full mb-8">
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1658387518136-703378fb6f48?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3NtZXRpYyUyMHBhY2thZ2luZyUyMGRlc2lnbnxlbnwxfHx8fDE3NTc0ODczODF8MA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Featured Cosmetic Packaging Design"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="grid grid-cols-3 gap-8">
            <div>
              <h3 className="serif text-2xl text-primary mb-3">Luxe Beauty</h3>
              <p className="sans text-sm text-muted-foreground">
                Premium cosmetic packaging design featuring elegant typography and metallic accents.
              </p>
            </div>
            <div>
              <h4 className="sans text-xs uppercase tracking-wide text-muted-foreground mb-3">Services</h4>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>• Brand Identity</li>
                <li>• Packaging Design</li>
                <li>• Typography</li>
              </ul>
            </div>
            <div>
              <h4 className="sans text-xs uppercase tracking-wide text-muted-foreground mb-3">Industry</h4>
              <p className="text-sm text-muted-foreground">Beauty & Cosmetics</p>
            </div>
          </div>
        </div>
      </div>

      {/* Project Grid */}
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-12 gap-8">
          {/* Large Project */}
          <div className="col-span-8">
            <Link to={`/project/${projects[0]?.id}`} className="group block">
              <div className="aspect-[4/3] overflow-hidden mb-6">
                <ImageWithFallback 
                  src={projects[0]?.mainImage || "https://images.unsplash.com/photo-1746422029285-e81d6650f17f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb29kJTIwcGFja2FnaW5nJTIwcHJlbWl1bXxlbnwxfHx8fDE3NTc0ODczODR8MA&ixlib=rb-4.1.0&q=80&w=1080"}
                  alt={projects[0]?.title || "Food Packaging Design"}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="serif text-xl text-primary mb-2">{projects[0]?.title || "Artisan Food Co."}</h3>
                  <p className="sans text-sm text-muted-foreground">{projects[0]?.description || "Premium food packaging with hand-lettered typography"}</p>
                </div>
                <span className="sans text-xs text-muted-foreground uppercase tracking-wide">2024</span>
              </div>
            </Link>
          </div>

          {/* Side Projects */}
          <div className="col-span-4 space-y-8">
            {projects.slice(1, 3).map((project, index) => (
              <Link key={project.id} to={`/project/${project.id}`} className="group block">
                <div className="aspect-[4/3] overflow-hidden mb-4">
                  <ImageWithFallback 
                    src={project.mainImage}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </div>
                <h4 className="serif text-lg text-primary mb-1">{project.title}</h4>
                <p className="sans text-xs text-muted-foreground">{project.category}</p>
              </Link>
            ))}
          </div>
        </div>

        {/* Bottom Row - Three Equal Columns */}
        <div className="grid grid-cols-3 gap-8 mt-16">
          {projects.slice(3, 6).map((project) => (
            <Link key={project.id} to={`/project/${project.id}`} className="group block">
              <div className="aspect-[4/5] overflow-hidden mb-6">
                <ImageWithFallback 
                  src={project.mainImage}
                  alt={project.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="text-center">
                <h4 className="serif text-lg text-primary mb-2">{project.title}</h4>
                <p className="sans text-xs text-muted-foreground uppercase tracking-wide">{project.category}</p>
              </div>
            </Link>
          ))}
        </div>

        {/* Additional Row - Four Projects */}
        <div className="grid grid-cols-4 gap-6 mt-16">
          {projects.slice(6, 10).map((project) => (
            <Link key={project.id} to={`/project/${project.id}`} className="group block">
              <div className="aspect-[4/5] overflow-hidden mb-4">
                <ImageWithFallback 
                  src={project.mainImage}
                  alt={project.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="text-center">
                <h4 className="serif text-base text-primary mb-1">{project.title}</h4>
                <p className="sans text-xs text-muted-foreground uppercase tracking-wide">{project.category}</p>
              </div>
            </Link>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-24 pt-16 border-t border-border">
          <h3 className="serif text-3xl text-primary mb-6">
            Have a Project in <span className="script-text">Mind?</span>
          </h3>
          <p className="editorial-text mb-8 max-w-xl mx-auto">
            Let's collaborate to create something extraordinary that captures your brand's essence 
            and resonates with your audience.
          </p>
          <Link 
            to="/about"
            className="inline-block px-12 py-4 border border-primary text-primary hover:bg-primary hover:text-primary-foreground transition-colors sans text-sm tracking-wider uppercase"
          >
            Get In Touch
          </Link>
        </div>
      </div>
    </main>
  );
}