import React from 'react';
import { Link } from 'react-router-dom';
import { projects } from '../data/projects';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function ProjectGrid() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      {projects.map((project) => (
        <Link 
          key={project.id} 
          to={`/project/${project.id}`}
          className="group block"
        >
          <div className="overflow-hidden rounded-lg bg-muted/20">
            <div className="aspect-[4/3] overflow-hidden">
              <ImageWithFallback 
                src={project.mainImage}
                alt={project.title}
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
            </div>
            <div className="p-6">
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-lg font-medium group-hover:text-primary transition-colors">
                  {project.title}
                </h3>
                <span className="text-sm text-muted-foreground">{project.year}</span>
              </div>
              <p className="text-sm text-muted-foreground mb-2">{project.client}</p>
              <p className="text-sm text-muted-foreground">{project.description}</p>
            </div>
          </div>
        </Link>
      ))}
    </div>
  );
}