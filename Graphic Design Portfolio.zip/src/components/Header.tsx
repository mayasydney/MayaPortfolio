import React from 'react';
import { Link, useLocation } from 'react-router-dom';

export function Header() {
  const location = useLocation();

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 p-8 bg-background/80 backdrop-blur-sm">
      <div className="flex justify-between items-start">
        <div className="sans text-xs text-muted-foreground leading-relaxed tracking-wide">
          <div className="uppercase">Creative Director</div>
          <div>Available for Projects</div>
          <div>hello@mc-studio.com</div>
        </div>
        
        <nav className="flex space-x-12 sans text-xs tracking-[0.15em] uppercase">
          <Link 
            to="/" 
            className={`transition-colors relative pb-1 ${
              isActive('/') 
                ? 'text-primary after:absolute after:bottom-0 after:left-0 after:w-full after:h-px after:bg-primary' 
                : 'text-muted-foreground hover:text-primary'
            }`}
          >
            Home
          </Link>
          <Link 
            to="/gallery" 
            className={`transition-colors relative pb-1 ${
              isActive('/gallery') 
                ? 'text-primary after:absolute after:bottom-0 after:left-0 after:w-full after:h-px after:bg-primary' 
                : 'text-muted-foreground hover:text-primary'
            }`}
          >
            Portfolio
          </Link>
          <Link 
            to="/about" 
            className={`transition-colors relative pb-1 ${
              isActive('/about') 
                ? 'text-primary after:absolute after:bottom-0 after:left-0 after:w-full after:h-px after:bg-primary' 
                : 'text-muted-foreground hover:text-primary'
            }`}
          >
            About
          </Link>
        </nav>

        <div className="sans text-xs text-muted-foreground text-right leading-relaxed tracking-wide">
          <div className="uppercase">MC Studio</div>
          <div>New York, NY</div>
          <div>Est. 2020</div>
        </div>
      </div>
    </header>
  );
}